//  [6/4/2015 uty]
#ifndef _PROTECTUSERPAGE_H_
#define _PROTECTUSERPAGE_H_
//-----------------------------------------------------------------------------//
NTSTATUS
InitProtectUserPage (
	__in PDRIVER_OBJECT DriverObject
	);
//-----------------------------------------------------------------------------//
#endif