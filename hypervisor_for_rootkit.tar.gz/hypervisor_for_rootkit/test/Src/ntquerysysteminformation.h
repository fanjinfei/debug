//  [7/19/2015 uty]
#ifndef _NTQUERYSYSTEMINFORMATION_H_
#define _NTQUERYSYSTEMINFORMATION_H_
//-----------------------------------------------------------------------------//
NTSTATUS
TestInvisibleNtQuerySystemInformationInlineHook (
	VOID
	);
//-----------------------------------------------------------------------------//
#endif