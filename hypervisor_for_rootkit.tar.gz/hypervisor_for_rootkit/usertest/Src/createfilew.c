//  [6/18/2015 uty]
#include <windows.h>
//-----------------------------------------------------------------------------//
typedef
HANDLE
(WINAPI *PCREATEFILEW)(
    __in     LPCWSTR lpFileName,
    __in     DWORD dwDesiredAccess,
    __in     DWORD dwShareMode,
    __in_opt LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    __in     DWORD dwCreationDisposition,
    __in     DWORD dwFlagsAndAttributes,
    __in_opt HANDLE hTemplateFile
    );
//-----------------------------------------------------------------------------//
VOID CreateFileWTrampoline_win7sp1(VOID);
VOID CreateFileWTrampoline_win8_1(VOID);
PCREATEFILEW OriginalCreateFileW = NULL;
//-----------------------------------------------------------------------------//
HANDLE
WINAPI
CreateFileWHook(
    __in     LPCWSTR lpFileName,
    __in     DWORD dwDesiredAccess,
    __in     DWORD dwShareMode,
    __in_opt LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    __in     DWORD dwCreationDisposition,
    __in     DWORD dwFlagsAndAttributes,
    __in_opt HANDLE hTemplateFile
    )
{
	OutputDebugStringW(L"CreateFileWHook:");
	OutputDebugStringW(lpFileName);
	OutputDebugStringW(L"\n\n");

	return OriginalCreateFileW(lpFileName,
		                       dwDesiredAccess,
							   dwShareMode,
							   lpSecurityAttributes,
							   dwCreationDisposition,
							   dwFlagsAndAttributes,
							   hTemplateFile);
}
//-----------------------------------------------------------------------------//
LONG
InlineHookCreateFileW (
	__in PVOID Function,
	__in PVOID FunctionHook
	)
{
	UCHAR TmpTrampoline[20] = {0};
	LARGE_INTEGER FuncAddress = {0};

	PUCHAR pTrampoline = NULL;

	DWORD dwOldProtect = 0;


	FuncAddress.QuadPart = (LONGLONG)FunctionHook;

	// PUSH <Low Absolute Address DWORD>
	// ; Only if required (when High half is non zero):
	// MOV [RSP+4], DWORD <High Absolute Address DWORD>
	// RET
	TmpTrampoline[0] = 0x68;
	*(PULONG)&TmpTrampoline[1] = FuncAddress.LowPart;
	*(PULONG)&TmpTrampoline[5] = 0x042444C7;
	*(PULONG)&TmpTrampoline[9] = FuncAddress.HighPart;
	TmpTrampoline[13] = 0xC3;
	TmpTrampoline[14] = 0x90;
	TmpTrampoline[15] = 0x90;
	TmpTrampoline[16] = 0x90;
	TmpTrampoline[17] = 0x90;
	TmpTrampoline[18] = 0x90;
	TmpTrampoline[19] = 0x90;


	FuncAddress.QuadPart = (LONGLONG)Function + 20;
	
	//pTrampoline = (PUCHAR)CreateFileWTrampoline_win7sp1 + 20;
	pTrampoline = (PUCHAR)CreateFileWTrampoline_win8_1 + 20;
	//DisableWriteProtect();
	VirtualProtect(pTrampoline, 14, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	pTrampoline[0] = 0x68;
	*(PULONG)&pTrampoline[1] = FuncAddress.LowPart;
	*(PULONG)&pTrampoline[5] = 0x042444C7;
	*(PULONG)&pTrampoline[9] = FuncAddress.HighPart;
	pTrampoline[13] = 0xC3;
	//EnableWriteProtect();
	VirtualProtect(pTrampoline, 14, dwOldProtect, &dwOldProtect);

	//OriginalCreateFileW = (PCREATEFILEW)CreateFileWTrampoline_win7sp1;
	OriginalCreateFileW = (PCREATEFILEW)CreateFileWTrampoline_win8_1;


	//DisableWriteProtect();
	VirtualProtect(Function, 20, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	memcpy(Function, TmpTrampoline, 20);
	//EnableWriteProtect();
	VirtualProtect(Function, 20, dwOldProtect, &dwOldProtect);


	return ERROR_SUCCESS;
}
//-----------------------------------------------------------------------------//