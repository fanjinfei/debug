//  [6/3/2015 uty]
#include <Windows.h>
#include <stdio.h>
#include "../../include/usertest.h"
#include "createfilew.h"
//-----------------------------------------------------------------------------//
typedef
HANDLE
(WINAPI *PCREATEFILEA)(
    __in     LPCSTR lpFileName,
    __in     DWORD dwDesiredAccess,
    __in     DWORD dwShareMode,
    __in_opt LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    __in     DWORD dwCreationDisposition,
    __in     DWORD dwFlagsAndAttributes,
    __in_opt HANDLE hTemplateFile
    );
//-----------------------------------------------------------------------------//
VOID CreateFileATrampoline(VOID);
PCREATEFILEA OriginalCreateFileA = NULL;
//-----------------------------------------------------------------------------//
HANDLE
WINAPI
CreateFileAHook(
    __in     LPCSTR lpFileName,
    __in     DWORD dwDesiredAccess,
    __in     DWORD dwShareMode,
    __in_opt LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    __in     DWORD dwCreationDisposition,
    __in     DWORD dwFlagsAndAttributes,
    __in_opt HANDLE hTemplateFile
    )
{
	OutputDebugStringA("CreateFileAHook:");
	OutputDebugStringA(lpFileName);
	OutputDebugStringA("\n\n");

	return OriginalCreateFileA(lpFileName,
		                       dwDesiredAccess,
							   dwShareMode,
							   lpSecurityAttributes,
							   dwCreationDisposition,
							   dwFlagsAndAttributes,
							   hTemplateFile);
}
//-----------------------------------------------------------------------------//
LONG
InlineHookCreateFileA (
	__in PVOID Function,
	__in PVOID FunctionHook
	)
{
	UCHAR TmpTrampoline[16] = {0};
	LARGE_INTEGER FuncAddress = {0};

	PUCHAR pTrampoline = NULL;

	DWORD dwOldProtect = 0;


	FuncAddress.QuadPart = (LONGLONG)FunctionHook;

	// PUSH <Low Absolute Address DWORD>
	// ; Only if required (when High half is non zero):
	// MOV [RSP+4], DWORD <High Absolute Address DWORD>
	// RET
	TmpTrampoline[0] = 0x68;
	*(PULONG)&TmpTrampoline[1] = FuncAddress.LowPart;
	*(PULONG)&TmpTrampoline[5] = 0x042444C7;
	*(PULONG)&TmpTrampoline[9] = FuncAddress.HighPart;
	TmpTrampoline[13] = 0xC3;
	TmpTrampoline[14] = 0x90;
	TmpTrampoline[15] = 0x90;


	FuncAddress.QuadPart = (LONGLONG)Function + 16;
	
	pTrampoline = (PUCHAR)CreateFileATrampoline + 16;
	//DisableWriteProtect();
	VirtualProtect(pTrampoline, 14, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	pTrampoline[0] = 0x68;
	*(PULONG)&pTrampoline[1] = FuncAddress.LowPart;
	*(PULONG)&pTrampoline[5] = 0x042444C7;
	*(PULONG)&pTrampoline[9] = FuncAddress.HighPart;
	pTrampoline[13] = 0xC3;
	//EnableWriteProtect();
	VirtualProtect(pTrampoline, 14, dwOldProtect, &dwOldProtect);

	OriginalCreateFileA = (PCREATEFILEA)CreateFileATrampoline;


	//DisableWriteProtect();
	VirtualProtect(Function, 16, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	memcpy(Function, TmpTrampoline, 16);
	//EnableWriteProtect();
	VirtualProtect(Function, 16, dwOldProtect, &dwOldProtect);


	return ERROR_SUCCESS;
}
//-----------------------------------------------------------------------------//
LONG
ProtectPage (
	__in PUSER_SHADOW_PAGE UserShadowPage
	)
{
	LONG Status = -1;
	BOOL bResult = FALSE;
	int nReturnLength = 0;

	HANDLE	hDevice = INVALID_HANDLE_VALUE;

	hDevice  = CreateFile(
		HYPERVISOR_DEVICE_LINK_NAME,
		GENERIC_WRITE | GENERIC_READ,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL, 
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
		);
	if (hDevice == INVALID_HANDLE_VALUE)
	{
		printf("CreateFile fail %d\n", GetLastError());
		goto Exit0;
	}

	bResult = DeviceIoControl(
		hDevice,
		IOCTL_HYPERVISOR_PROTECT_PAGE,
		(BYTE*)UserShadowPage,
		sizeof(USER_SHADOW_PAGE),
		NULL,
		0,
		&nReturnLength,
		NULL
		);

	if (FALSE == bResult)
	{
		printf("DeviceIoControl fail %d\n", GetLastError());
		goto Exit0;
	}

	Status = ERROR_SUCCESS;
Exit0:
	if (INVALID_HANDLE_VALUE != hDevice)
	{
		CloseHandle(hDevice);
	}
	return Status;
}
//-----------------------------------------------------------------------------//
int TestHookCreateFileA (VOID)
{
	PVOID pCreateFileA = NULL;
	HMODULE hKernel32 = NULL;
	PVOID pPageAddress = NULL;
	USER_SHADOW_PAGE UserShadowPage = {0};
	DWORD dwOldProtect = 0;
	BOOL bResult = FALSE;
	DWORD dw4bytes = 0;

	hKernel32 = LoadLibrary(L"kernel32.dll");
	pCreateFileA = GetProcAddress(hKernel32, "CreateFileA");
	if (NULL == pCreateFileA)
	{
		goto Exit0;
	}

	printf("pCreateFileA 0x%p, first 4 bytes 0x%x\n", pCreateFileA, *(PULONG)pCreateFileA);

	//
	// trigger copy on write
	//

	bResult = VirtualProtect(pCreateFileA, 4, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	if (FALSE == bResult)
	{
		printf("VirtualProtect fail %d\n", GetLastError());
		goto Exit0;
	}

	dw4bytes = *(PULONG)pCreateFileA;

	*(PULONG)pCreateFileA = dw4bytes;


	bResult = VirtualProtect(pCreateFileA, 4, dwOldProtect, &dwOldProtect);
	if (FALSE == bResult)
	{
		printf("VirtualProtect fail %d\n", GetLastError());
		goto Exit0;
	}

	bResult = VirtualLock(pCreateFileA, 4);
	if (FALSE == bResult)
	{
		printf("VirtualLock fail %d\n", GetLastError());
		goto Exit0;
	}

	pPageAddress = (ULONG_PTR)pCreateFileA & 0xFFFFFFFFFFFFF000;
	printf("0x%p\n", pPageAddress);

	UserShadowPage.VirtualPageAddress = pPageAddress;
	memcpy(UserShadowPage.PageContent, pPageAddress, PAGE_SIZE);

	InlineHookCreateFileA((PVOID)pCreateFileA, (PVOID)CreateFileAHook);

	ProtectPage(&UserShadowPage);

	while (TRUE)
	{
		HANDLE hFile     = INVALID_HANDLE_VALUE;

		printf("CreateFileA first 4 bytes 0x%x\n", *(PULONG)pCreateFileA);
		hFile = CreateFileA("test.tmp",               // file name 
			GENERIC_READ,          // open for reading 
			0,                     // do not share 
			NULL,                  // default security 
			CREATE_ALWAYS,         // existing file only 
			FILE_ATTRIBUTE_NORMAL, // normal file 
			NULL);                 // no template 
		if (hFile == INVALID_HANDLE_VALUE) 
		{ 
			printf("CreateFileA fail %d\n", GetLastError());
			break;
		}

		CloseHandle(hFile);

		Sleep(2000);
	}

Exit0:
	return 0;
}
//-----------------------------------------------------------------------------//
int TestHookCreateFileW (VOID)
{
	PVOID pCreateFileW = NULL;
	HMODULE hKernelBase = NULL;
	PVOID pPageAddress = NULL;
	USER_SHADOW_PAGE UserShadowPage = {0};
	DWORD dwOldProtect = 0;
	BOOL bResult = FALSE;
	DWORD dw4bytes = 0;

	hKernelBase = LoadLibrary(L"kernelbase.dll");
	pCreateFileW = GetProcAddress(hKernelBase, "CreateFileW");
	if (NULL == pCreateFileW)
	{
		goto Exit0;
	}

	printf("pCreateFileW 0x%p, first 4 bytes 0x%x\n", pCreateFileW, *(PULONG)pCreateFileW);

	//
	// trigger copy on write
	//

	bResult = VirtualProtect(pCreateFileW, 4, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	if (FALSE == bResult)
	{
		printf("VirtualProtect fail %d\n", GetLastError());
		goto Exit0;
	}

	dw4bytes = *(PULONG)pCreateFileW;

	*(PULONG)pCreateFileW = dw4bytes;


	bResult = VirtualProtect(pCreateFileW, 4, dwOldProtect, &dwOldProtect);
	if (FALSE == bResult)
	{
		printf("VirtualProtect fail %d\n", GetLastError());
		goto Exit0;
	}

	bResult = VirtualLock(pCreateFileW, 4);
	if (FALSE == bResult)
	{
		printf("VirtualLock fail %d\n", GetLastError());
		goto Exit0;
	}

	pPageAddress = (ULONG_PTR)pCreateFileW & 0xFFFFFFFFFFFFF000;
	printf("0x%p\n", pPageAddress);

	UserShadowPage.VirtualPageAddress = pPageAddress;
	memcpy(UserShadowPage.PageContent, pPageAddress, PAGE_SIZE);

	InlineHookCreateFileW((PVOID)pCreateFileW, (PVOID)CreateFileWHook);

	ProtectPage(&UserShadowPage);

	while (TRUE)
	{
		HANDLE hFile     = INVALID_HANDLE_VALUE;

		printf("CreateFileW first 4 bytes 0x%x\n", *(PULONG)pCreateFileW);
		hFile = CreateFileW(L"test.tmp",               // file name 
			GENERIC_READ,          // open for reading 
			0,                     // do not share 
			NULL,                  // default security 
			CREATE_ALWAYS,         // existing file only 
			FILE_ATTRIBUTE_NORMAL, // normal file 
			NULL);                 // no template 
		if (hFile == INVALID_HANDLE_VALUE) 
		{ 
			printf("CreateFileW fail %d\n", GetLastError());
			break;
		}

		CloseHandle(hFile);

		Sleep(2000);
	}

Exit0:
	return 0;
}
//-----------------------------------------------------------------------------//
int main(void)
{
	
	TestHookCreateFileW();

	return 0;
}
//-----------------------------------------------------------------------------//
BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  // handle to DLL module
    DWORD fdwReason,     // reason for calling function
    LPVOID lpReserved )  // reserved
{
    // Perform actions based on the reason for calling.
    switch( fdwReason ) 
    { 
        case DLL_PROCESS_ATTACH:
         // Initialize once for each new process.
         // Return FALSE to fail DLL load.
			{
				PVOID pCreateFileW = NULL;
				HMODULE hKernelBase = NULL;
				PVOID pPageAddress = NULL;
				USER_SHADOW_PAGE UserShadowPage = {0};
				DWORD dwOldProtect = 0;
				BOOL bResult = FALSE;
				DWORD dw4bytes = 0;

				hKernelBase = LoadLibrary(L"kernelbase.dll");
				pCreateFileW = GetProcAddress(hKernelBase, "CreateFileW");
				if (NULL == pCreateFileW)
				{
					break;
				}

				//
				// trigger copy on write
				//

				bResult = VirtualProtect(pCreateFileW, 4, PAGE_EXECUTE_READWRITE, &dwOldProtect);
				if (FALSE == bResult)
				{
					OutputDebugStringA("VirtualProtect fail\n");
					break;
				}

				dw4bytes = *(PULONG)pCreateFileW;

				*(PULONG)pCreateFileW = dw4bytes;


				bResult = VirtualProtect(pCreateFileW, 4, dwOldProtect, &dwOldProtect);
				if (FALSE == bResult)
				{
					OutputDebugStringA("VirtualProtect fail\n");
					break;
				}

				bResult = VirtualLock(pCreateFileW, 4);
				if (FALSE == bResult)
				{
					printf("VirtualLock fail %d\n", GetLastError());
					break;
				}

				pPageAddress = (ULONG_PTR)pCreateFileW & 0xFFFFFFFFFFFFF000;

				UserShadowPage.VirtualPageAddress = pPageAddress;
				memcpy(UserShadowPage.PageContent, pPageAddress, PAGE_SIZE);

				InlineHookCreateFileW((PVOID)pCreateFileW, (PVOID)CreateFileWHook);

				ProtectPage(&UserShadowPage);
			}
            break;

        case DLL_THREAD_ATTACH:
         // Do thread-specific initialization.
            break;

        case DLL_THREAD_DETACH:
         // Do thread-specific cleanup.
            break;

        case DLL_PROCESS_DETACH:
         // Perform any necessary cleanup.
            break;
    }
    return TRUE;  // Successful DLL_PROCESS_ATTACH.
}
//-----------------------------------------------------------------------------//