//  [6/18/2015 uty]
#ifndef _CREATEFILEW_H_
#define _CREATEFILEW_H_
//-----------------------------------------------------------------------------//
HANDLE
WINAPI
CreateFileWHook(
    __in     LPCWSTR lpFileName,
    __in     DWORD dwDesiredAccess,
    __in     DWORD dwShareMode,
    __in_opt LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    __in     DWORD dwCreationDisposition,
    __in     DWORD dwFlagsAndAttributes,
    __in_opt HANDLE hTemplateFile
    );

LONG
InlineHookCreateFileW (
	__in PVOID Function,
	__in PVOID FunctionHook
	);
//-----------------------------------------------------------------------------//
#endif