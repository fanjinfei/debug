//  [5/15/2015 uty]
#ifndef _COMMON_H_
#define _COMMON_H_
//-----------------------------------------------------------------------------//
VOID ClearBit(ULONG nr, PULONG addr);
VOID SetBit(ULONG nr, PULONG addr);
//-----------------------------------------------------------------------------//
#endif