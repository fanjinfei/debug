How to compile:

WDK7 or below: replace makefile with makefile.bak. Under src directory, for example "hypervisor\Src", type "BLD" to compile.


WDK8 or above:

Step1: change WDK path in makefile

# Valid combinations of compilers & WDKs:
#     VS2012 + WDK 8.0 (Microsoft Windows 7)
#     VS2013 + WDK 8.1 (Microsoft Windows 8.1)
#     VS2015 + WDK 8.1 (Microsoft Windows 10)
#
WDK=C:\Program Files (x86)\Windows Kits\10

Step2: Under the src directory, execute vcvarsall.bat, for example:

C:\hypervisor_for_rootkit\hypervisor\Src>"C:\Program Files (x86)\Microsoft Visual Studio 14.0\vc\vcvarsall.bat" amd64

Step3:  nmake


Note:
Each project compiled separately, batteries not included
