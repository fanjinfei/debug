//  [5/4/2015 uty]
#ifndef _COMMON_ASM_H_
#define _COMMON_ASM_H_
//-----------------------------------------------------------------------------//
VOID StartVMX(VOID);
VOID StartVMXBack(VOID);

VOID _INVD(VOID);
//-----------------------------------------------------------------------------//
#endif