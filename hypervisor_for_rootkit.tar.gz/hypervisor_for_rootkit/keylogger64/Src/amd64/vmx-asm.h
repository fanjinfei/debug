//  [5/4/2015 uty]
#ifndef _VMX_ASM_H_
#define _VMX_ASM_H_
//-----------------------------------------------------------------------------//
VOID VmxTurnOn (PHYSICAL_ADDRESS VmxonPA);
VOID VmxPtrld (PHYSICAL_ADDRESS VmcsPA);
VOID VmxClear(PHYSICAL_ADDRESS VmcsPA);
VOID VmxWrite (ULONG64 Field, ULONG64 Value);
ULONG64 VmxRead (ULONG64 Field);
VOID VmxLaunch (VOID);

VOID VmxExitHandler (VOID);

VOID VmxVmCall2(ULONG64 num, ULONG64 arg0, ULONG64 arg1);
//-----------------------------------------------------------------------------//
#endif