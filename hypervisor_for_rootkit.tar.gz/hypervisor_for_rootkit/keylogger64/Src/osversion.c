//  [2/23/2016 uty]
#include <ntddk.h>
#include "osversion.h"
//-----------------------------------------------------------------------------//
OSVERSION
UtGetVersion (
	VOID
	)
{
	RTL_OSVERSIONINFOEXW OsVerEx = {sizeof(RTL_OSVERSIONINFOEXW)};

	////DEBUG_BREAK;

	RtlGetVersion((PRTL_OSVERSIONINFOW)&OsVerEx);

	switch (OsVerEx.dwMajorVersion)
	{
	case 5:
		switch (OsVerEx.dwMinorVersion)
		{

		case 0:	
			{
				return enumNotSupported;
			}
			break;

			//
			// 5.1	windows xp
			//
		case 1:
			if (0 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsXP_ServicePack0;
			}
			else if (1 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsXP_ServicePack1;
			}
			else if (2 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsXP_ServicePack2;
			}
			else if (3 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsXP_ServicePack3;
			}
			else
			{
				return enumNotSupported;
			}

			break;

			//
			// 5.2	windows 2003
			//
		case 2:
			if (0 == OsVerEx.wServicePackMajor)
			{
				return enumWindows2003_ServicePack0;
			}
			else if (1 == OsVerEx.wServicePackMajor)
			{
				return enumWindows2003_ServicePack1;
			}
			else if (2 == OsVerEx.wServicePackMajor)
			{
				return enumWindows2003_ServicePack2;
			}
			else
			{
				return enumNotSupported;
			}
			break;
		}
		break;

	case 6:
		switch (OsVerEx.dwMinorVersion)
		{
			//
			// 6.0	windows vista
			//

		case 0:
			if (0 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsVista_ServicePack0;
			}
			else if (1 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsVista_ServicePack1;
			}
			else if (2 == OsVerEx.wServicePackMajor)
			{
				return enumWindowsVista_ServicePack2;
			}
			else
			{
				return enumNotSupported;
			}

			break;

			//
			// 6.1	windows 7
			//

		case 1:
			if (0 == OsVerEx.wServicePackMajor)
			{
				return enumWindows7_ServicePack0;
			}
			else if (1 == OsVerEx.wServicePackMajor)
			{
				return enumWindows7_ServicePack1;
			}
			else
			{
				return enumNotSupported;
			}

			break;

			//
			// 6.2	windows 8
			//

		case 2:
			if (0 == OsVerEx.wServicePackMajor)
			{
				return enumWindows8_ServicePack0;
			}
			else
			{
				return enumNotSupported;
			}
		}
		break;

	case 10:
		{
			switch (OsVerEx.dwMinorVersion)
			{

				//
				// 10.0	Windows 10
				//

			case 0:
				
				if (0 == OsVerEx.wServicePackMajor)
				{
					return enumWindows10_ServicePack0;
				}
				else
				{
					return enumNotSupported;
				}

				break;
			}
		}
		break;
	default:
		return enumNotSupported;
		break;
	}

	return enumNotSupported;
}
//-----------------------------------------------------------------------------//