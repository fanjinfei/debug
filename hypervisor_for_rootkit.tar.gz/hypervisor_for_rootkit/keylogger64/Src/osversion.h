//  [2/23/2016 uty]
#ifndef _OSVERSION_H_
#define _OSVERSION_H_
//-----------------------------------------------------------------------------//
typedef
enum _OSVERSION
{
	enumNotSupported = 0x1022,
	enumWindows2000_ServicePack0,
	enumWindows2000_ServicePack1,
	enumWindows2000_ServicePack2,
	enumWindows2000_ServicePack3,
	enumWindows2000_ServicePack4,
	enumWindowsXP_ServicePack0,
	enumWindowsXP_ServicePack1,
	enumWindowsXP_ServicePack2,
	enumWindowsXP_ServicePack3,
	enumWindows2003_ServicePack0,
	enumWindows2003_ServicePack1,
	enumWindows2003_ServicePack2,
	enumWindowsVista_ServicePack0,
	enumWindowsVista_ServicePack1,
	enumWindowsVista_ServicePack2,
	enumWindows7_ServicePack0,
	enumWindows7_ServicePack1,
	enumWindows8_ServicePack0,
	enumWindows10_ServicePack0,
} OSVERSION;
//-----------------------------------------------------------------------------//
OSVERSION
UtGetVersion (
	VOID
	);
//-----------------------------------------------------------------------------//
#endif