# 
# Copyright (c) 2010, 2014, IBM Corp. All rights reserved. 
#     
# This program is free software: you can redistribute it and/or modify 
# it under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
# GNU General Public License for more details. 
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>. 
#

# nz.matrix implementation

`nz.matrix` <-
function (name, prefix="NZ_MAT_DATA_") {
   table = paste(prefix,name,sep="")
	# check the table name
	if (is.character(table)) {
		if (!nzExistMatrixByName(name))
			stop("matrix '", name, "' table '",table,"' does not exist")
	}
	else
		stop("currently only an existing table name can be passed as the table argument")

	return(new(Class="nz.matrix", table=table, name=name, where="", cols=as.character(NULL), rowsno=as.integer(NULL), colsno=as.integer(NULL)))
}

# ---------------------------------------------------------------------

`is.nz.matrix` <-
function(x) {
	return(inherits(x, "nz.matrix"))
}

# ---------------------------------------------------------------------

setGeneric("isSparse",
	useAsDefault = function (x) {
		stop("casting from data type '", class(x), "' is not implemented yet")
	}
) 


setMethod("isSparse", signature(x="nz.matrix"),
	function (x) {
	  # tnrows = nzScalarQuery(paste("select count(*) from ",x@table))
	  # return (tnrows < prod(dim(x)))
	  return (FALSE)
	}
)


setMethod("as.matrix", signature(x="nz.matrix"), 
	function (x, max.rows=NULL, isSp=isSparse(x), ...) {
   if (isSp) {
      # efficient for spare matrices
  		return(nzSparse2matrix(materialize(x, max.rows=max.rows)))
   } else {
      # efficient for full matrices
      if(nzIsUpper()) {
        nzqr = paste("select * FROM INZA.NZ_MAT_DATA_", x@name, " order by COL, ROW", sep="")        
      } else {
        nzqr = paste("select * FROM INZA.NZ_MAT_DATA_", x@name, " order by col, row", sep="")                
      }
      xdim = dim(x)
      return(matrix(nzQuery(nzqr)[, 3] , xdim[1], xdim[2]))
   }
	}
)

# ---------------------------------------------------------------------

setMethod("dim", signature(x="nz.matrix"),
	function(x) {
		if (length(x@rowsno) == 0)
			x@rowsno <- nzScalarQuery(paste("call nzm..get_num_rows('", x@name,"')", sep=""))
		if (length(x@colsno) == 0)
			x@colsno <- nzScalarQuery(paste("call nzm..get_num_cols('", x@name,"')", sep=""))
		if (is.na(x@rowsno)) x@rowsno=0
		if (is.na(x@colsno)) x@colsno=0
		return(c(x@rowsno, x@colsno))
	}
)

# ---------------------------------------------------------------------

nzGetValidMatrixName <- function (prefix = "MAT") {
	while (TRUE) {
		name = paste(prefix, floor(runif(1,0,1000000)), sep="")
			if (!nzExistMatrixByName(name))
				return(name)
	}
}


nzCallMatrixSP <- function(procName, parameters, trace=F) {
	nzCheckConnection()
	query = paste("CALL ",procName,"(", paste("'", parameters, "'", sep="", collapse=", "), ")")
  if (trace)
      cat(query,"\n\n")
  nzQuery(query)
}

callMatrixOperator <- function(parameters, operator, trace=F) {
	nzCheckConnection()
	query = paste("CALL nzm.._matrix_matrix_operation(", paste("'", parameters, "'", sep="", collapse=", "), ", '", operator,"')")
  if (trace)
      cat(query,"\n\n")
  nzQuery(query)
}


#nzSVD <-  function(x, nu=NULL, nv=NULL, LINPACK=NULL) {
nzSVD <-  function(x, nu=NULL, nv=NULL, LINPACK=FALSE) {
	resultu = nzGetValidMatrixName()
	results = nzGetValidMatrixName()
	resultvt = nzGetValidMatrixName()
	nzCallMatrixSP("nzm..svd", c(x@name, resultu, results, resultvt))

	U = nz.matrix(resultu)
	S = nz.matrix(results)
	VT = nz.matrix(resultvt)
	V = t(VT)
	return(list(u = U, s = S, vt=VT, v = V))
}


#setMethod("svd", signature(x="nz.matrix", nu="ANY", nv="ANY", LINPACK="ANY"),
setMethod("svd", signature(x="nz.matrix"),
	nzSVD
)


nzEigen <- function(x) {
   	 resultw = nzGetValidMatrixName()
   	 resultz = nzGetValidMatrixName()
         nzCallMatrixSP("nzm..eigen", c(x@name, resultw, resultz))
	W = nz.matrix(resultw)
	Z = nz.matrix(resultz)
 	 return(list(w = W, z = Z))
}
   
setMethod("t", signature(x="nz.matrix"),
	function(x) {
   	result = nzGetValidMatrixName()
	  nzCallMatrixSP("nzm..transpose", c(x@name, result))
	  
		return(nz.matrix(result))
	}
)

# ---------------------------------------------------------------------

setMethod("dim<-", signature(x="nz.matrix", value="ANY"),
	function(x, value) stop("you cannot overwrite this", call.=FALSE)
)

# ---------------------------------------------------------------------

setMethod("NROW", signature(x="nz.matrix"),
	function(x) { 
	if (is.na(nrow(x))) dim(x)
  return(nrow(x)) }
)

# ---------------------------------------------------------------------

setMethod("NCOL", signature(x="nz.matrix"),
	function(x) { 
	if (is.na(nrow(x))) dim(x)
  return(ncol(x)) }
)


# ---------------------------------------------------------------------

setMethod("names", signature(x="nz.matrix"),
	function(x) { return(x@cols) }
)

# ---------------------------------------------------------------------

`materialize` <-
function (nzmat, max.rows=NULL) {
	return(nzQuery(nzmat.query(nzmat, max.rows=max.rows)))
}

# ---------------------------------------------------------------------

`nzmat.query` <-
function (nzmat, max.rows=NULL) {
	if (!is.element(class(nzmat), c("nz.matrix")))
		stop(paste("cannot join object of class: ", class(nzdf)))

	if (is.null(nzmat@table))
		stop("table name unknown")

	paste("SELECT row, col, value FROM ", nzmat@table)
}

# ---------------------------------------------------------------------

setMethod("print", signature(x="nz.matrix"),
	function (x, ...) {
		cat(nzmat.query(x),"\n")
	}
)

# ---------------------------------------------------------------------


nzSparse2matrix <- function(rcv) {
  if (nrow(rcv)==0) 
      return(matrix(0,0,0))
  if (ncol(rcv)<3) 
      stop(simpleError("three columns are expected in the row-column-value format!!!"))
  nr = max(rcv[,1])
  nc = max(rcv[,2])
  mat = matrix(0,nr,nc)
  for (i in 1:nrow(rcv)) 
     mat[rcv[i,1],rcv[i,2]]=rcv[i,3]
  mat
}


setMethod("[", signature(x = "nz.matrix", i="ANY", j="ANY"), 
	function (x, i= NULL, j= NULL, ..., drop=NA)
	{ 
	  tableOut = nzGetValidMatrixName()
    if (!nzExistMatrix(x)) 
        stop(paste("Matrix", x@name, "does not exist!"))
    dim(x)
    if (is.na(nrow(x))  || is.na(ncol(x)) ) 
        stop(paste("Matrix", x@name, " is empty!"))
	  xran = c(1, nrow(x))
	  yran = c(1, ncol(x))
		# check arguments - columns
		if (try(!is.null(i), silent=T )==T) 
		  xran = range(i, na.rm=T)
		if (try(!is.null(j), silent=T)==T) 
		  yran = range(j, na.rm=T)
    nzCallMatrixSP("nzm..copy_submatrix", c(x@name, tableOut, xran[1], xran[2], yran[1], yran[2]))
    return(nz.matrix(tableOut))
	}
)  


nzInv <- function(x) {
   	 result = nzGetValidMatrixName()
          nzCallMatrixSP("nzm..inverse", c(x@name, result))
	  return(nz.matrix(result))
}

nzSolveLLS <- function(a,b) {
     result = nzGetValidMatrixName()
     nzCallMatrixSP("nzm..solve_linear_least_squares", c(a@name, b@name, result))
     return(nz.matrix(result))
}

nzSolve <- function(a, b, tol=NULL, LINPACK=NULL) {
	result = nzGetValidMatrixName()
	if (is.null(b)) { # nzInverse
		nzCallMatrixSP("nzm..inverse", c(a@name, result))
	} else {          # nzSolve          
		nzCallMatrixSP("nzm..solve", c(a@name, b@name, result))
	}
	return(nz.matrix(result))
}

setMethod("solve", signature(a="nz.matrix", b="nz.matrix"),
	nzSolve
)

nzExistMatrix <- function(x) {
  if (!("name" %in% slotNames(x)))
    return(F) # x is not an object of nzmatrix
	nzExistMatrixByName(x@name)
}

nzExistMatrixByName <- function(x) {
	as.vector(nzCallMatrixSP("nzm..matrix_exists", x)[,1])=="t"
}
 
nzDeleteMatrix <- function(x) {
  if (nzExistMatrix(x)) {
  	nzCallMatrixSP("nzm..delete_matrix", x@name)
	 } else {
    cat("Matrix ", x@name, " does not exist!\n")
	 }
}
nzDeleteMatrixByName <- function(x) {
  if (nzExistMatrixByName(x)) {
  	nzCallMatrixSP("nzm..delete_matrix", x)
	 } else {
    cat("Matrix ", x, " does not exist!\n")
	 }
}

nzDeleteAllMatrices <- function() {
	nzQuery("CALL NZM..DELETE_ALL_MATRICES")
}

setGeneric("as.nz.matrix",
	useAsDefault = function (x, name = NULL) {
		stop("casting from data type '", class(x), "' is not implemented yet")
	}
) 

setMethod("as.nz.matrix", signature(x="matrix"),
  function (x, name = NULL) {
    if (is.null(name)) 
       name = nzGetValidMatrixName();

	  rcv = data.frame(row = rep(1:nrow(x), times=ncol(x)), col = rep(1:ncol(x), each=nrow(x)), value = c(x))
    if(nzIsUpper()) {
      colnames(rcv) <- toupper(colnames(rcv))
    }
	  as.nz.data.frame(rcv, name)
	  
	  nzQuery("call nzm..create_matrix_from_table('",name,"', '",name,"', ",nrow(x),", ",ncol(x),")");
	  nzQuery("drop table ",name)

		return(nz.matrix(name))
	}
)
	
rounding <- function(x, digits=1) {
    if (!nzExistMatrix(x)) 
        stop(paste("Matrix", x@name, "does not exist!"))
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..round_elements", c(x@name, tableOut,digits))
	   return(nz.matrix(tableOut))
  }

ln <- function(x) {
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..ln_elements", c(x@name, tableOut))
	   return(nz.matrix(tableOut))
}

mod <- function(x, dvr) {
    if (!nzExistMatrix(x)) {
        stop(paste("Matrix", x@name, "does not exist!"))
    }
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..mod_elements", c(x@name, tableOut, dvr))
	   return(nz.matrix(tableOut))
}

nzElementwiseMatrixOperations <- function(e1, op="+", num=1) {
    if (!nzExistMatrix(e1)) 
        stop(paste("Matrix", e1@name, "does not exist!"))
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..scalar_operation", c(e1@name, tableOut, op, num))
	   return(nz.matrix(tableOut))
}

add <- function(e1, num=1) {
    if (!nzExistMatrix(e1)) 
        stop(paste("Matrix", e1@name, "does not exist!"))
    nzElementwiseMatrixOperations(e1, op="+", num)
}

subt <- function(e1, num=1) {
    if (!nzExistMatrix(e1)) 
        stop(paste("Matrix", e1@name, "does not exist!"))
    nzElementwiseMatrixOperations(e1, op="-", num)
}

mult <- function(e1, num=1) {
    if (!nzExistMatrix(e1)) 
        stop(paste("Matrix", e1@name, "does not exist!"))
    nzElementwiseMatrixOperations(e1, op="*", num)
}

div <- function(e1, num=1) {
    if (!nzExistMatrix(e1)) 
        stop(paste("Matrix", e1@name, "does not exist!"))
    nzElementwiseMatrixOperations(e1, op="/", num)
}


nzKronecker <- function(X, Y) {
    if (!nzExistMatrix(X) || !nzExistMatrix(Y)) {
        stop(paste("Matrix", X@name,"or",Y@name, "does not exist!"))
    }
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..Kronecker", c(X@name, Y@name, tableOut))
	   return(nz.matrix(tableOut))
}
setMethod("%x%", signature(X="nz.matrix", Y="nz.matrix"),
	function(X,Y) 
	   return(nzKronecker(X, Y))
)

nzPowerMatrix <- function(x, num=2) {
    if (!nzExistMatrix(x)) 
        stop(paste("Matrix", x@name, "does not exist!"))
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..mtx_pow2", c(x@name, num, tableOut))
	   return(nz.matrix(tableOut))
}

pow <- function(x, num=2) {
    if (!nzExistMatrix(x)) 
        stop(paste("Matrix", x@name, "does not exist!"))
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..power_elements", c(x@name, tableOut, num))
	   return(nz.matrix(tableOut))
}

vecdiag <- function(x) {
    if (!nzExistMatrix(x)) 
        stop(paste("Matrix", x@name, "does not exist!"))
	   tableOut = nzGetValidMatrixName(); 
	   nzCallMatrixSP("nzm..vec_to_diag", c(x@name, tableOut))
	   return(nz.matrix(tableOut))
}
nzVecToDiag <- vecdiag

nzCBind <- function(x, y) {
    if (!nzExistMatrix(x) || !nzExistMatrix(y)) 
        stop(paste("Matrix", x@name,"or",y@name, "does not exist!"))
	  tableOut = nzGetValidMatrixName(); 
	  nzCallMatrixSP("nzm..concat", c(x@name, y@name, tableOut, "h"))
	  return(nz.matrix(tableOut))
}
nzRBind <- function(x, y) {
    if (!nzExistMatrix(x) || !nzExistMatrix(y)) 
        stop(paste("Matrix", x@name,"or",y@name, "does not exist!"))
	  tableOut = nzGetValidMatrixName(); 
	  nzCallMatrixSP("nzm..concat", c(x@name, y@name, tableOut, "v"))
	  return(nz.matrix(tableOut))
}

.nzTmpOperators = cbind(c("<", ">", "<=", ">=", "==", "!="), 
                  c("nzm..lt", "nzm..gt", "nzm..le", "nzm..ge", "nzm..eq", "nzm..ne"))

invisible(apply(.nzTmpOperators, 1,
	function(x) setMethod(x[1], signature(e1="nz.matrix", e2="nz.matrix"),
		function (e1, e2) {
      if (!nzExistMatrix(e1) || !nzExistMatrix(e2)) 
          stop(paste("Matrix", e1@name,"or",e2@name, "does not exist!"))
     	result = nzGetValidMatrixName()
     	nzCallMatrixSP(x[2], c(e1@name, e2@name, result))
  	  return(nz.matrix(result))
		}
	)
)) 

.nzTmpSOperators = cbind(c("abs", "exp", "trunc", "sqrt", "ceiling","floor", "log10"), 
                              c("nzm..abs_elements", "nzm..exp_elements", "nzm..int_elements", "nzm..sqrt_elements", "nzm..ceil_elements", "nzm..floor_elements","nzm..log_elements"))

invisible(apply(.nzTmpSOperators, 1,
	function(el) setMethod(el[1], signature(x="nz.matrix"),
		function (x) {
      if (!nzExistMatrix(x)) 
          stop(paste("Matrix", x@name,"does not exist!"))
     	result = nzGetValidMatrixName()
     	nzCallMatrixSP(el[2], c(x@name, result))
  	  return(nz.matrix(result))
		}
	)
)) 

.nzSimpleOperators = c("+", "-", "*", "/")

invisible(sapply(.nzSimpleOperators, 
	function(el) setMethod(el[1], signature(e1="nz.matrix", e2="nz.matrix"),
	function(e1, e2) {
      if (!nzExistMatrix(e1) || !nzExistMatrix(e2)) 
          stop(paste("Matrix", e1@name,"or",e2@name, "does not exist!"))
     	result = nzGetValidMatrixName()
   	  callMatrixOperator(c(e1@name, e2@name, result), el[1])
  	  return(nz.matrix(result))
		}
	)
)) 

# ---------------------------------------------------------------------

setMethod("%*%", signature(x="nz.matrix", y="nz.matrix"),
	function(x, y) {
   	result = nzGetValidMatrixName()
	  nzCallMatrixSP("nzm..gemm", c(x@name, y@name, result))
	  return(nz.matrix(result))
  }
)


nzPMax <- function(x, y) {
    if (!nzExistMatrix(x) || !nzExistMatrix(y)) 
        stop(paste("Matrix", x@name,"or",y@name, "does not exist!"))
	  tableOut = nzGetValidMatrixName(); 
	  nzCallMatrixSP("nzm..max", c(x@name, y@name, tableOut))
	  return(nz.matrix(tableOut))
}
nzPMin <- function(x, y) {
    if (!nzExistMatrix(x) || !nzExistMatrix(y)) 
        stop(paste("Matrix", x@name,"or",y@name, "does not exist!"))
	  tableOut = nzGetValidMatrixName(); 
	  nzCallMatrixSP("nzm..min", c(x@name, y@name, tableOut))
	  return(nz.matrix(tableOut))
}




nzIdentityMatrix <- function(size=1, name=NULL) {
  if (is.null(name))
     name = nzGetValidMatrixName(); 
  if (nzExistMatrixByName(name)) {
    cat("Matrix ", name, " already exist!\n")
	 } else {
  	nzCallMatrixSP("nzm..create_identity_matrix", c(name, size))
  	return(nz.matrix(name))
	 }
}

                       
#.nzTmpCreates = cbind(c("nzEmptyMatrix",  "nzRandomMatrix", "nzNormalMatrix", "nzOnesMatrix"),
#                           c("nzm..create_empty_matrix", "nzm..create_random_matrix", "nzm..normal","nzm..create_ones_matrix"))
#
#for (i in 1:nrow(.nzTmpCreates)) {
#  "<-"(.nzTmpCreates[i, 1], 	function(nrows=1, ncols=1, table=NULL) {
#    if (is.null(table))
#       table = nzGetValidMatrixName(); 
#    if (nzExistMatrixByName(table)) {
#      cat("Matrix ", table, " already exist!\n")
#  	 } else {
#    	nzCallMatrixSP(.nzTmpCreates[i,2], c(table, nrows, ncols))
#   	 }
#    return(nz.matrix(table)) 
#	})
#}
#
#.nzTmpOneValueOperators = cbind(c("tr", "nzMax", "nzMin", "nzSsq", "nzSum", "nzAll", "nzAny" ), 
#                              c("nzm..red_trace", "nzm..red_max", "nzm..red_min", "nzm..red_ssq", "nzm..red_sum", "nzm..all_nonzero", "nzm..any_nonzero"))
#
#for (i in 1:nrow(.nzTmpOneValueOperators)) {
#  "<-"(.nzTmpOneValueOperators[i, 1], 	function(x) {
#      if (!nzExistMatrix(x)) 
#          stop(paste("Matrix", x@name, "does not exist!"))
#      out = nzCallMatrixSP(.nzTmpOneValueOperators[i, 2], x@name)
#      return(out[[1]])
#		})
#}
#


# how to do it better?
                       
nzEmptyMatrix <- function(nrows=1, ncols=1, name=NULL) {
    if (is.null(name)) name = nzGetValidMatrixName(); 
    if (nzExistMatrixByName(name))   cat("Matrix ", name, " already exist!\n")
  	  else                          nzCallMatrixSP("nzm..create_empty_matrix", c(name, nrows, ncols))
    return(nz.matrix(name)) 
}
nzRandomMatrix <- function(nrows=1, ncols=1, name=NULL) {
    if (is.null(name)) name = nzGetValidMatrixName(); 
    if (nzExistMatrixByName(name))   cat("Matrix ", name, " already exist!\n")
  	  else                          nzCallMatrixSP("nzm..create_random_matrix", c(name, nrows, ncols))
    return(nz.matrix(name)) 
}
nzNormalMatrix <- function(nrows=1, ncols=1, name=NULL) {
    if (is.null(name)) name = nzGetValidMatrixName(); 
    if (nzExistMatrixByName(name))   cat("Matrix ", name, " already exist!\n")
  	  else                          nzCallMatrixSP("nzm..normal", c(name, nrows, ncols))
    return(nz.matrix(name)) 
}
nzOnesMatrix <- function(nrows=1, ncols=1, name=NULL) {
    if (is.null(name)) name = nzGetValidMatrixName(); 
    if (nzExistMatrixByName(name))   cat("Matrix ", name, " already exist!\n")
  	  else                          nzCallMatrixSP("nzm..create_ones_matrix", c(name, nrows, ncols))
    return(nz.matrix(name)) 
}
	
	
nzTr <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..red_trace", x@name)[[1]])
}
nzMaxAbs <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..red_max_abs", x@name)[[1]])
}
nzMax <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..red_max", x@name)[[1]])
}
nzMin <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..red_min", x@name)[[1]])
}
nzSsq <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..red_ssq", x@name)[[1]])
}
nzSum <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..red_sum", x@name)[[1]])
}
nzAll <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..all_nonzero", x@name)[[1]])
}
nzAny <- function(x) {
      if (!nzExistMatrix(x))    stop(paste("Matrix", x@name, "does not exist!"))
      return(nzCallMatrixSP("nzm..any_nonzero", x@name)[[1]])
}
		

nzCreateMatrixFromTable <- function(x, nrows, ncols, name=NULL) {
  if (is.null(name)) 
     name = nzGetValidMatrixName();
     
  if (is.nz.data.frame(x)) { 
       tmpView <- nzCreateView(x);
       nzQuery("call nzm..create_matrix_from_table('",tmpView,"', '",name,"', ",nrows,", ",ncols,")");
	   nzDropView(tmpView);
  } else { 
       # create matrix form table (x is a name)
       if (nzExistTable(x))  {
          nzQuery("call nzm..create_matrix_from_table('",x,"', '",name,"', ",nrows,", ",ncols,")");
       } else {
          stop(paste("Table", x, "does not exist!"))
       }
  }
    return(nz.matrix(name)) 
}

nzCreateTableFromMatrix <- function(name, table=NULL) {
  if (is.null(table)) 
     table =  nzGetValidTableName();
     
  if (nzExistMatrixByName(name)) {
       nzQuery("call nzm..CREATE_TABLE_FROM_MATRIX('",name,"', '",table,"')");
  } else {
       stop(paste("Matrix", name, "does not exist!"))
  }
  table
}

nzSetValue <- function(name, row, col, value) {
  if (is.nz.matrix(name) && nzExistMatrix(name))
   name = name@name;
  if (nzExistMatrixByName(name)) {
     nzQuery("call nzm..set_value('",name,"', ",row,", ",col,", ",value,")");
  } else {
       stop(paste("Matrix", name, "does not exist!"))
  }
}

nzShowMatrices <- function() {
   tmp = nzQuery("call nzm..List_matrices()")[[1]]
   if (!is.na(tmp)) {
			strsplit(tmp,"\n")[[1]]
	}
}

nzDiag <- function(namein, nameout=NULL) {
  if (is.null(nameout)) 
     nameout = nzGetValidMatrixName();
  if (is.nz.matrix(namein) && nzExistMatrix(namein))
     namein = namein@name;

  if (nzExistMatrixByName(namein)) {
     nzQuery("call nzm..vecdiag('",namein,"', '",nameout,"')");
  } else {
       stop(paste("Matrix", namein, "does not exist!"))
  }
    return(nz.matrix(nameout)) 
}

